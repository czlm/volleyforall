volleyforall 1.1 patch notes
New changes:
- implemented form validation
- improved user profile ux

p.s 
- timeline was referenced from the internet, everything other feature and design choice was organic.

thank you ms wang for the guidance :)